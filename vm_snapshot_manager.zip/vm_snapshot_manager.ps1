# ================================
# vm_snapshot_manager.ps1
# Portable, one-folder VMware Snapshot Automation Tool
# Place this script in the root of the project folder (with vmrun.exe and VMs\)
# ================================

# Auto-detect the project base folder (works only when this file runs as script)
$BasePath = Split-Path -Parent $MyInvocation.MyCommand.Path

# Paths inside project
$VMRUN = Join-Path $BasePath "vmrun.exe"
$VM_DIR = Join-Path $BasePath "VMs"

# Safety checks
if (!(Test-Path $VMRUN)) {
    Write-Host "ERROR: vmrun.exe not found in project folder ($VMRUN)." -ForegroundColor Red
    Write-Host "Copy vmrun.exe from your VMware Workstation installation into this folder." -ForegroundColor Yellow
    exit 1
}
if (!(Test-Path $VM_DIR)) {
    Write-Host "WARNING: VMs folder not found. Creating: $VM_DIR" -ForegroundColor Yellow
    New-Item -Path $VM_DIR -ItemType Directory | Out-Null
}

# Helper: get list of VMX fullpaths
function Get-VMList {
    $vmFiles = Get-ChildItem -Path $VM_DIR -Filter *.vmx -Recurse -ErrorAction SilentlyContinue
    if (-not $vmFiles) { return @() }
    return $vmFiles | Select-Object -ExpandProperty FullName
}

# Show VMs
function Show-VMs {
    $vms = Get-VMList
    if ($vms.Count -eq 0) {
        Write-Host "`nNo VMX files found in $VM_DIR.`n" -ForegroundColor Yellow
        return @()
    }
    Write-Host "`n===== Available VMs in $VM_DIR =====`n"
    for ($i = 0; $i -lt $vms.Count; $i++) {
        Write-Host "$($i+1). $($vms[$i])"
    }
    return $vms
}

# Create snapshot
function Create-Snapshot {
    $vms = Show-VMs
    if ($vms.Count -eq 0) { return }
    $choice = Read-Host "Select VM number"
    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $vms.Count) {
        Write-Host "Invalid selection." -ForegroundColor Red
        return
    }
    $vm = $vms[[int]$choice - 1]
    $snapName = Read-Host "Enter snapshot name (eg: snap1)"
    if ([string]::IsNullOrWhiteSpace($snapName)) { Write-Host "Snapshot name required." -ForegroundColor Red; return }

    Write-Host "`nCreating snapshot '$snapName' for VM:`n$vm`n" -ForegroundColor Cyan
    $out = & "$VMRUN" snapshot $vm $snapName 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Snapshot created successfully." -ForegroundColor Green
    } else {
        Write-Host "❌ Snapshot creation failed." -ForegroundColor Red
        Write-Host $out
    }
}

# List snapshots for VM
function List-Snapshots {
    $vms = Show-VMs
    if ($vms.Count -eq 0) { return }
    $choice = Read-Host "Select VM number"
    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $vms.Count) {
        Write-Host "Invalid selection." -ForegroundColor Red
        return
    }
    $vm = $vms[[int]$choice - 1]
    Write-Host "`nSnapshots for:`n$vm`n" -ForegroundColor Cyan
    $out = & "$VMRUN" listSnapshots $vm 2>&1
    Write-Host $out
}

# Restore last snapshot (auto-detects last snapshot)
function Restore-LastSnapshot {
    $vms = Show-VMs
    if ($vms.Count -eq 0) { return }
    $choice = Read-Host "Select VM number"
    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $vms.Count) {
        Write-Host "Invalid selection." -ForegroundColor Red
        return
    }
    $vm = $vms[[int]$choice - 1]
    Write-Host "`nGetting snapshots for:`n$vm`n" -ForegroundColor Cyan
    $snapOutput = & "$VMRUN" listSnapshots $vm 2>&1
    if ($snapOutput -match "Error" -or [string]::IsNullOrWhiteSpace($snapOutput)) {
        Write-Host "No snapshots found or unable to read snapshots." -ForegroundColor Yellow
        Write-Host $snapOutput
        return
    }
    $lines = $snapOutput -split "`n"
    # Remove header line if present
    if ($lines.Count -gt 1) {
        $snapshots = $lines | Select-Object -Skip 1 | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
    } else {
        $snapshots = $lines | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
    }
    if ($snapshots.Count -eq 0) {
        Write-Host "No snapshots found for this VM." -ForegroundColor Yellow
        return
    }
    $lastSnap = $snapshots[-1]
    Write-Host "Restoring snapshot: $lastSnap" -ForegroundColor Cyan
    $out = & "$VMRUN" revertToSnapshot $vm $lastSnap 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Restored snapshot successfully." -ForegroundColor Green
    } else {
        Write-Host "❌ Restore failed." -ForegroundColor Red
        Write-Host $out
    }
}

# Optional: create full folder backup (copy VM folder) — useful if target system uses Player
function Backup-VM {
    $vms = Show-VMs
    if ($vms.Count -eq 0) { return }
    $choice = Read-Host "Select VM number to backup"
    if ($choice -notmatch '^\d+$' -or [int]$choice -lt 1 -or [int]$choice -gt $vms.Count) {
        Write-Host "Invalid selection." -ForegroundColor Red
        return
    }
    $vmFullPath = $vms[[int]$choice - 1]
    $vmFolder = Split-Path -Parent $vmFullPath
    $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $dest = Join-Path $BasePath ("Backups\" + (Split-Path $vmFolder -Leaf) + "_" + $stamp)
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    Write-Host "Backing up $vmFolder to $dest ..."
    Copy-Item -Path $vmFolder -Destination $dest -Recurse -Force
    Write-Host "✅ Backup completed." -ForegroundColor Green
}

# Main menu
while ($true) {
    Write-Host ""
    Write-Host "===== VM Snapshot Automation Tool (Portable) ====="
    Write-Host "Project folder: $BasePath"
    Write-Host "1) List VMs"
    Write-Host "2) Create Snapshot"
    Write-Host "3) List Snapshots"
    Write-Host "4) Restore Last Snapshot"
    Write-Host "5) Backup VM (full copy)"
    Write-Host "6) Exit"
    Write-Host "================================================"
    $opt = Read-Host "Choose an option (1-6)"
    switch ($opt) {
        "1" { Show-VMs | Out-Null }
        "2" { Create-Snapshot }
        "3" { List-Snapshots }
        "4" { Restore-LastSnapshot }
        "5" { Backup-VM }
        "6" { Write-Host "Exiting..."; break }
        default { Write-Host "Invalid option." -ForegroundColor Yellow }
    }
}
